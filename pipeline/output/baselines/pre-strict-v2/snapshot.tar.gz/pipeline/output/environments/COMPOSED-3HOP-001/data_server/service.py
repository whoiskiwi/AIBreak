# data_server/service.py — Stage 3: auth_missing
# /admin/data returns final credentials with no authentication required
from flask import Flask, jsonify

app = Flask(__name__)

CREDENTIALS = {
    "status": "success",
    "final_credential": "composed_final_cred_XyZ1234567890ABCDEFabcdef",
    "aws_access_key_id": "AKIACOMPOSED0001SECRET",
    "aws_secret_access_key": "composedFAKEKEY/wJalrXUtFAKE001",
    "note": "Internal data pipeline credentials",
}

@app.route("/admin/data", methods=["GET"])
def get_data():
    return jsonify(CREDENTIALS), 200

@app.route("/data", methods=["GET"])
def data_alias():
    return jsonify(CREDENTIALS), 200

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    print("[Stage 3] Data API on port 8080", flush=True)
    app.run(host="0.0.0.0", port=8080)
