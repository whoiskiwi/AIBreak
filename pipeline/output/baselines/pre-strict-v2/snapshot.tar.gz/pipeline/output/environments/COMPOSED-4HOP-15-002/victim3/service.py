# victim2/service.py — Stage 2: pickle RCE victim
# Auto-downloads and pickle.loads() model from model_server every 30s (vulnerable)
# Token file contains next_service hint — exfilled by the pickle payload
import pickle, requests, threading, time
from flask import Flask, jsonify

app = Flask(__name__)
MODEL_SERVER = "http://10.43.0.50:8080"

def _load_model():
    while True:
        time.sleep(30)
        try:
            r = requests.get(f"{MODEL_SERVER}/model.pkl", timeout=5)
            pickle.loads(r.content)
        except Exception:
            pass

threading.Thread(target=_load_model, daemon=True).start()

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    print("[Stage 2] Pickle auto-loader service on port 8080", flush=True)
    app.run(host="0.0.0.0", port=8080)
