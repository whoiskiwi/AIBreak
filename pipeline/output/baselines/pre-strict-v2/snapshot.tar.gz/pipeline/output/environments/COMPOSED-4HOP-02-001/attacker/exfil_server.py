from flask import Flask, request
import json

app = Flask(__name__)
received = []

@app.route("/exfil", methods=["POST"])
@app.route("/", methods=["POST"])
@app.route("/<path:path>", methods=["POST"])
def exfil(path="exfil"):
    data = request.get_data(as_text=True)
    received.append(data)
    print(f"\n[+] Data received ({len(data)} bytes)", flush=True)
    return "ok", 200

@app.route("/received", methods=["GET"])
def get_received():
    return json.dumps(received), 200

if __name__ == "__main__":
    print("[*] Exfil server (catchall) on 0.0.0.0:9999", flush=True)
    app.run(host="0.0.0.0", port=9999, threaded=True)
