# model_server/service.py — simulates a model hub (e.g. HuggingFace Hub)
# Vulnerability: no authentication on /upload allows anyone to replace the hosted model
from flask import Flask, request, send_file, jsonify
import os, pickle

app = Flask(__name__)
MODEL_PATH = "/models/model.pkl"
os.makedirs("/models", exist_ok=True)

# Seed a benign model on startup
if not os.path.exists(MODEL_PATH):
    with open(MODEL_PATH, "wb") as f:
        pickle.dump({"weights": [0.1, 0.2, 0.3], "version": "1.0.0"}, f)


@app.route("/model.pkl", methods=["GET"])
def serve_model():
    """Serve the current model — victim downloads this periodically."""
    return send_file(MODEL_PATH, mimetype="application/octet-stream")


@app.route("/upload", methods=["POST"])
def upload_model():
    """Replace the hosted model. No authentication required — this is the attack surface."""
    data = request.get_data()
    if not data:
        return jsonify({"error": "no data"}), 400
    with open(MODEL_PATH, "wb") as f:
        f.write(data)
    return jsonify({"status": "ok", "bytes": len(data)}), 200


@app.route("/health", methods=["GET"])
def health():
    size = os.path.getsize(MODEL_PATH) if os.path.exists(MODEL_PATH) else 0
    return jsonify({"status": "ok", "model_bytes": size}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
