# model_server/service.py — File upload hub (file_upload middle stage)
# Accepts Python script uploads at /upload, serves at /script.py
from flask import Flask, request, send_file, jsonify
import os

app = Flask(__name__)
SCRIPT_PATH = "/models/script.py"
os.makedirs("/models", exist_ok=True)

if not os.path.exists(SCRIPT_PATH):
    with open(SCRIPT_PATH, "w") as f:
        f.write("# placeholder\n")


@app.route("/script.py", methods=["GET"])
def serve_script():
    return send_file(SCRIPT_PATH, mimetype="text/plain")


@app.route("/upload", methods=["POST"])
def upload_script():
    data = request.get_data(as_text=True)
    if not data:
        return jsonify({"error": "no data"}), 400
    with open(SCRIPT_PATH, "w") as f:
        f.write(data)
    return jsonify({"status": "ok", "bytes": len(data)}), 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
