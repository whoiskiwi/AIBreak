# victim1/service.py — Stage 1: path traversal
# /read?path= reads any file without sanitization
# /app/config.json is pre-seeded with model_server address (the connector)
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route("/read", methods=["GET"])
def read_file():
    path = request.args.get("path")
    if not path:
        return jsonify({"error": "Missing required field: path"}), 400
    try:
        with open(path) as f:
            return f.read(), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    print("[Stage 1] Path traversal service on port 8080", flush=True)
    app.run(host="0.0.0.0", port=8080)
