# victim1/service.py — Stage 1: code injection
# INTERNAL_MODEL_SERVER env var is planted in the Dockerfile — readable via RCE ("; env")
from flask import Flask, request, jsonify
import subprocess

app = Flask(__name__)

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json()
    if not data or "branch_name" not in data:
        return jsonify({"error": "Missing required field: branch_name"}), 400
    cmd = f"echo Checking out {data['branch_name']}"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return jsonify({"output": result.stdout + result.stderr})

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    print("[Stage 1] Code injection service on port 8080", flush=True)
    app.run(host="0.0.0.0", port=8080)
