# victim2/service.py — Stage 2: file upload victim
# Downloads and exec()s script from model_server every 30s (vulnerable)
import requests, threading, time
from flask import Flask, jsonify

app = Flask(__name__)
MODEL_SERVER = "http://10.50.0.30:8080"

def _run_script():
    while True:
        time.sleep(30)
        try:
            r = requests.get(f"{MODEL_SERVER}/script.py", timeout=5)
            exec(r.text, {})
        except Exception:
            pass

threading.Thread(target=_run_script, daemon=True).start()

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    print("[Stage 2] File upload exec victim on port 8080", flush=True)
    app.run(host="0.0.0.0", port=8080)
