## CVE-2026-4372 — Layer3 — MAX_RETRIES
```
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/sessions.py", line 651, in request
    resp = self.send(prep, **send_kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/sessions.py", line 784, in send
    r = adapter.send(request, **kwargs)
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/adapters.py", line 729, in send
    raise ConnectionError
```

## CVE-2026-5241 — Layer3 — EXPLOIT_FAIL
```
Exploit failed:  {"error":"repo_url is required"}


```

## CVE-2026-54316 — Layer3 — EXPLOIT_FAIL
```
Attack payload sent to victim.

```

## CVE-2026-40904 — Layer1 — ENDPOINT_MISMATCH

## CVE-2026-12480 — Layer3 — MAX_RETRIES
```
Traceback (most recent call last):
  File "/attack/exploit.py", line 4, in <module>
    import h5py
ModuleNotFoundError: No module named 'h5py'

```

## CVE-2026-9335 — Layer3 — MAX_RETRIES
```
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/sessions.py", line 651, in request
    resp = self.send(prep, **send_kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/sessions.py", line 784, in send
    r = adapter.send(request, **kwargs)
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/adapters.py", line 729, in send
    raise ConnectionE
```

## CVE-2026-4372 — Layer3 — MAX_RETRIES
```
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/sessions.py", line 651, in request
    resp = self.send(prep, **send_kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/sessions.py", line 784, in send
    r = adapter.send(request, **kwargs)
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.11/site-packages/requests/adapters.py", line 729, in send
    raise ConnectionError
```

## CVE-2026-12480 — Layer3 — MAX_RETRIES
```
Traceback (most recent call last):
  File "/attack/exploit.py", line 6, in <module>
    'file': ('exploit.h5', open('exploit.h5', 'rb'), 'application/octet-stream')
                           ^^^^^^^^^^^^^^^^^^^^^^^^
FileNotFoundError: [Errno 2] No such file or directory: 'exploit.h5'

```

## CVE-2026-54316 — Layer3 — EXPLOIT_FAIL
```
Attack payload sent successfully!

```

## CVE-2026-12480 — Layer3 — MAX_RETRIES
```
Traceback (most recent call last):
  File "/attack/exploit.py", line 4, in <module>
    import h5py
ModuleNotFoundError: No module named 'h5py'

```

## CVE-2024-3568 — Layer3 — BUILD_FAIL
```
failed to solve: process "/bin/sh -c apt-get install -y openssh-client && rm -rf /var/lib/apt/lists/*" did not complete successfully: exit code: 100

```

## CVE-2024-3568 — Layer3 — BUILD_FAIL
```
failed to solve: process "/bin/sh -c mkdir /var/run/sshd &&     sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config &&     echo 'PermitRootLogin no' >> /etc/ssh/sshd_config" did not complete successfully: exit code: 1

```

## CVE-2024-2206 — Layer3 — EXPLOIT_FAIL
```
Failed to manipulate proxy URLs

```

## CVE-2026-45804 — Layer3 — EXPLOIT_FAIL
```
Exploit failed.

```

## CVE-2026-4372 — Layer3 — EXPLOIT_FAIL
```
Failed to deliver exploit payload.

```

## CVE-2026-5241 — Layer3 — EXPLOIT_FAIL
```
Failed to deliver payload.

```
